# Weather-Journal App Project

## Overview
This is a simple Weather Journal to apply using an external API.
this project uses the Open Weather Map API to retrieve weather updates using ZIP code
## Instructions
Download the whole project and run the `server.js` file using `node server.js`.
